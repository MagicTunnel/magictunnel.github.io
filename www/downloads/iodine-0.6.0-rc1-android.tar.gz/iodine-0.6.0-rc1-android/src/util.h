#ifndef __UTIL_H__
#define __UTIL_H__

char *get_resolvconf_addr();

#endif
